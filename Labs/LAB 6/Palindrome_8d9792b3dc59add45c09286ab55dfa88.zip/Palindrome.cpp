#include <iostream>
using namespace std;

int length (char str[]) {
	int i = 0;
	
	while (str[i] != '\0')
		i = i + 1;
		
	return i;
}


void reverse (char str1[], char str2[]) {
	int i, j, len;
	
	len = length (str1);			// find the number of characters in str1
	
	str2[len] = '\0';				// put NULL as last character in str2

	i = len - 1;					// ignore terminating NULL character
	for (j=0; j<len; j=j+1) {		// copy the characters from str1 to str2
		str2[j] = str1[i];			//   in reverse order
		i = i - 1;
	}
}


char upperToLower (char c) {
	if (c >= 'A' && c <= 'Z')
		c = c + ' ';
	
	return c;
}


bool isEqual (char str1[], char str2[]) {
	int i = 0;
	
	while (str1[i] != '\0') {
		char c1 = upperToLower(str1[i]);		// convert to lowercase
		char c2 = upperToLower(str2[i]);		// convert to lowercase	
									
		if (c2 == '\0' || c1 != c2)
			return false;
			
		i = i + 1;
	}
	
	if (str2[i] != '\0')		// there are still characters in str2
		return false;
		
	return true;
}


bool isPalindrome (char word[]) {
	char temp[100];
	
	reverse (word, temp);		// reverse word and store in temp
	if (isEqual(word, temp))	// check if word and temp are equal
		return true;
	else
		return false;
}


int main() {
	
	char str[100];
	int i;
	
	for (i=1; i<=5; i=i+1) {
		cout << "Please enter a string: ";
		cin >> str;
		if (isPalindrome(str))
			cout << str << " is a palindrome." << endl;
		else
			cout << str << " is NOT a palindrome." << endl;
	}
	
    return 0;
}
